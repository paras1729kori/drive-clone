

<?php $__env->startSection('content'); ?>
    <div class="px-4">
        <h1>Create Messages</h1>
        <?php echo Form::open(['action' => 'PostsController@store', 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

            <div class="form-group">
                <?php echo e(Form::label('title', 'Title')); ?>

                <?php echo e(Form::text('title', '', ['class' => 'form-control', 'placeholder' => 'Title'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('body', 'Body')); ?>

                <?php echo e(Form::textarea('body', '', ['class' => 'form-control', 'placeholder' => 'Body Text'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::checkbox('general', '1')); ?>

                <?php echo e(Form::label('general', 'General Message')); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('reciever', 'Personal')); ?>

                <select class="form-control opt" name="reciever" id="reciever">
                    <option value="nullable">Select Folder</option>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($user->id != auth()->user()->id): ?>
                      <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
            </div>
            <?php echo e(Form::submit('Submit', ['class'=>'btn btn-primary mb-2'])); ?>

        <?php echo Form::close(); ?>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\DriveClone\Converse\resources\views/posts/create.blade.php ENDPATH**/ ?>