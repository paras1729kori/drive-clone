

<?php $__env->startSection('content'); ?>
    <div class="px-2">
    <h4 class="font-weight-bold">Folders</h4>
    <?php if(count($fols) > 0): ?>
      <table class="table table-borderless table-hover">
        <thead id="table_pc">
          <tr>
            <th>Shared In</th>
            <th>Folder Name</th>
            <th>Created By</th>
            <th>Edit</th>
            <th>Delete</th>
          </tr>
        </thead>
      <?php $__currentLoopData = $fols; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tbody>
          <tr id="table_pc">
            <td>
              <?php if($fol->starred == '1'): ?>
                <i style="color:yellow;" class="fa fa-star mr-2" aria-hidden="true"></i>
              <?php else: ?>
                <i class="fa fa-star-o mr-2" aria-hidden="true"></i>
              <?php endif; ?>

              <?php if($fol->favourites == '1'): ?>
                <i style="color:red;" class="fa fa-heart" aria-hidden="true"></i>
              <?php else: ?>
                <i class="fa fa-heart-o" aria-hidden="true"></i>
              <?php endif; ?>
            </td>
            <td><a href="/important/<?php echo e($fol->id); ?>" style="color: #08417a;"><?php echo e($fol->name); ?></a></td>
            <td><?php echo e($fol->userfols->name); ?></td>
            <td><a href="/folders/<?php echo e($fol->id); ?>/edit"><i id="icon" class="fa fa-pencil-square icon" aria-hidden="true" class = "icon"></i></a></td>
            <td>
              <?php echo Form::open(['action' => ['FoldersController@destroy', $fol->id], 'method' => 'DELETE']); ?>

                  <button type="submit" style="border: 0px; background-color:white;"><i id="icon" class="fa fa-trash icon" aria-hidden="true" class = "icon"></i></button>
              <?php echo Form::close(); ?>

            </td>
          </tr>
        </tbody>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <thead id="table_mobile">
        <tr>
          <th>Folder Name</th>
          <th>Shared In</th>
          <th>Edit</th>
          <th>Delete</th>
        </tr>
      </thead>
      <?php $__currentLoopData = $fols; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tbody>
          <tr id="table_mobile">
            <td><a href="/important/<?php echo e($fol->id); ?>" style="color: #08417a;"><?php echo e($fol->name); ?></a></td>
            <td>
              <?php if($fol->starred == '1'): ?>
                  <i style="color:yellow;" class="fa fa-star mr-2" aria-hidden="true"></i>
                <?php else: ?>
                  <i class="fa fa-star-o mr-2" aria-hidden="true"></i>
                <?php endif; ?>
                <?php if($fol->favourites == '1'): ?>
                  <i style="color:red;" class="fa fa-heart" aria-hidden="true"></i>
                <?php else: ?>
                  <i class="fa fa-heart-o" aria-hidden="true"></i>
                <?php endif; ?>
            </td>
            <td><a href="/folders/<?php echo e($fol->id); ?>/edit"><i id="icon" class="fa fa-pencil-square icon" aria-hidden="true" class = "icon"></i></a></td>
            <td>
              <?php echo Form::open(['action' => ['FoldersController@destroy', $fol->id], 'method' => 'DELETE']); ?>

                  <button type="submit" style="border: 0px; background-color:white;"><i id="icon" class="fa fa-trash icon" aria-hidden="true" class = "icon"></i></button>
              <?php echo Form::close(); ?>

            </td>
          </tr>
        </tbody>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>  
    <?php else: ?>
      <p>No Folders Found</p>
  <?php endif; ?>
        <br>
        <h4 class="font-weight-bold">Files</h4>
        <?php if(count($fils) > 0): ?>
        <form method="GET">
          <?php echo csrf_field(); ?>
          <button formaction="/replace" type="submit" class="btn btn-primary">Replace Files</button>
        <table class="table table-borderless table-hover" id="tdata">
            <thead>
              <tr id="table_pc">
                <th>Select All <input type="checkbox" class="selectall1"></th>
                <th>Shared In</th>
                <th>File Name</th>
                <th>Created By</th>
                <th>Parent Folder</th>
                <th>last Modified at</th>
                <th>Size</th>
              </tr>
            </thead>
                <?php $__currentLoopData = $fils; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tbody>
                    <tr id="table_pc">
                        <td><input type="checkbox" name="ids[]" class="selectbox1" value="<?php echo e($fil->id); ?>"></td>
                    </form>
                        <td>
                          <?php if($fil->starred == '1'): ?>
                            <i style="color:yellow;" class="fa fa-star" aria-hidden="true"></i>
                          <?php else: ?>
                            <i class="fa fa-star-o" aria-hidden="true"></i>
                          <?php endif; ?>

                          <?php if($fil->favourites == '1'): ?>
                            <i style="color:red;" class="fa fa-heart" aria-hidden="true"></i>
                          <?php else: ?>
                            <i class="fa fa-heart-o" aria-hidden="true"></i>
                          <?php endif; ?>
                        </td>
                        <td><a href="<?php echo e(route('downloadfileindash', $fil->id)); ?>" style="text-decoration: none;"><?php echo e($fil->name); ?></a></td>
                        <td><?php echo e($fil->userfils->name); ?></td>
                        <td><?php echo e($fil->p_files->name); ?></td>
                        <td><?php echo e($fil->updated_at); ?></td>
                        <td><?php echo e($fil->size); ?></td>
                    </tr>
                    </tbody>
                <tbody>
                    <tr id="table_mobile">
                        <td class="text-center">
                            <div id="accordion" role="tablist">
                                <div class="card">
                                  <div class="card-header" role="tab" id="headingOne">
                                    <h5 class="mb-0">
                                      <a data-toggle="collapse" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                        <?php echo e($fil->name); ?>

                                      </a>
                                    </h5>
                                  </div>                             
                                  <div id="collapseOne" class="collapse" role="tabpanel" aria-labelledby="headingOne">
                                    <div class="card-body">
                                      <a href="<?php echo e(route('downloadfileindash', $fil->id)); ?>" style="text-decoration: none;"><?php echo e($fil->name); ?></a><br>
                                      Created By: <?php echo e($fil->userfils->name); ?> <br>
                                      last modified at: <?php echo e($fil->updated_at); ?> <br>
                                      Size: <?php echo e(($fil->size)); ?><br>
                                      <?php echo Form::open(['action' => ['FilesController@destroy', $fil->id], 'method' => 'DELETE']); ?>

                                        <button class="btn btn-sm btn-danger" type="submit">Delete</button>
                                      <?php echo Form::close(); ?>

                                    </div>
                                  </div>
                                </div>
                            </div>
                        </td>
                      </tr>
                    </tbody>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </table>
          <?php else: ?>
            <p>No Files Found</p>
          <?php endif; ?>
    </div>

    <script type="text/javascript">
      // for selecting all buttons of files
      $('.selectall1').click(function(){
        $('.selectbox1').prop('checked', $(this).prop('checked'));
      })
      $('.selectbox1').change(function(){
        var total = $('.selectbox1').length;
        var number = $('.selectbox1:checked').length;
        if(total == number){
          $('.selectall1').prop('checked', true);
        } else{
          $('.selectall1').prop('checked', false);
        }
      })

      // for selecting all buttons of folders
      $('.selectall2').click(function(){
        $('.selectbox2').prop('checked', $(this).prop('checked'));
      })
      $('.selectbox2').change(function(){
        var total = $('.selectbox2').length;
        var number = $('.selectbox2:checked').length;
        if(total == number){
          $('.selectall2').prop('checked', true);
        } else{
          $('.selectall2').prop('checked', false);
        }
      })
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\DriveClone\Converse\resources\views/pages/search.blade.php ENDPATH**/ ?>