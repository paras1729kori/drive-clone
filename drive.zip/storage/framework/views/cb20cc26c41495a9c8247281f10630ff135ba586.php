

<?php $__env->startSection('title'); ?>
    Registered Roles
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
<div class="row">
    <div class="col-md-12">
      <div class="card">
        <div class="card-header">
          <h4 class="card-title"> Registered Roles</h4>
          <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
        </div>
        <div class="card-body">
          <div class="table-responsive" id="table_pc">
            <table class="table">
              <thead class=" text-primary">
                <th>Id</th>
                <th>Name</th>
                <th>Email</th>
                <th>UserType</th>
                <th>Status</th>
                <th>Edit</th>
                <th>Delete</th>
              </thead>
              <tbody>
                  <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><?php echo e($user->id); ?></td>
                        <td><?php echo e($user->name); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td><?php echo e($user->usertype); ?></td>
                        <td><?php echo e($user->status); ?></td>
                        <td><a href="/registeredit/<?php echo e($user->id); ?>" class="btn btn-success">EDIT</a></td>
                        <td>
                          <form action="/registerdelete/<?php echo e($user->id); ?>" method="post">
                            <?php echo e(csrf_field()); ?>

                            <?php echo e(method_field('DELETE')); ?>

                            <button type="submit" class="btn btn-danger">DELETE</button>
                          </form>
                        </td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  
              </tbody>
            </table>
          </div>
          <div class="table-responsive" id="table_mobile">
            <table class="table">
              <thead class=" text-primary">
                <th>Name</th>
                <th>UserType</th>
                <th>Status</th>
              </thead>
              <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                      <td><?php echo e($user->name); ?></td>
                      <td><?php echo e($user->usertype); ?></td>
                      <td><?php echo e($user->status); ?></td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
            </tbody>
          </table>
          <p>To Edit or Delete a User switch to Desktop View</p>
          </div>
        </div>
      </div>
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\DriveClone\Converse\resources\views/admin/register.blade.php ENDPATH**/ ?>