<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ config('APP_NAME', 'Converse') }}</title>

    <!--Link to Font Awesome Icons-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />

    <!-- Custom CSS -->
    

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="{{ asset('css/login.css') }}">
</head>
<body style="background-image: url({{ asset('img/loginpage.jpg') }}); color:white;">
    <div class="container text-center" style="padding-top:150px;">
        <div class="col-xs-4 col-xs-offset-4 jerry">
            
            <img class="mx-auto" style="border-radius: 10px;" src="{{asset('img/co.jpg')}}" alt="This is an image of logo">
            <h4 class="mt-2 header">Login</h4>

            <form method="POST" action="{{ route('login') }}">
                @csrf
                <div class="input-group w-75 ml-5">
                    {{-- Username --}}
                    <div class="input-group">
                      <span class="input-group-text mt-2"><i class="fa fa-user fa-lg icon tom" aria-hidden="true" class = "icon"></i></span>
    
                        <input id="email" type="email" class="form-control mt-2 @error('email') is-invalid @enderror" name="email" value="{{ old('email') }}" required autocomplete="email" autofocus>

                        @error('email')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                        @enderror
                    </div>
                    {{-- Password --}}
                    <div class="input-group pt-3">
                        <span class="input-group-text"><i class="fa fa-lock fa-lg icon tom" aria-hidden="true" class = "icon"></i></span>
                
                            <input id="password" type="password" class="form-control @error('password') is-invalid @enderror" name="password" required autocomplete="current-password">

                            @error('password')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        
                    </div>

                    {{-- Remember me --}}
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="remember" id="remember" {{ old('remember') ? 'checked' : '' }}>

                            <label class="form-check-label" for="remember">
                                {{ __('Remember Me') }}
                            </label>
                        </div>

                    {{-- Login button and Forgot Password --}}
                    <div class="form-check">
                        <button type="submit" class="btn btn-primary px-5 mt-4 mb-2" style="border-radius:50px; background-color: #08417a;"><i class="fa fa-sign-in fa-lg icon mr-1" aria-hidden="true" class = "icon"></i>
                            {{ __('Login') }}
                        </button>
                    </div>
                </div>
            </form>
            {{-- <a class="btn btn-link" href="/resetpassword">Reset Password</a> --}}
        </div>
    </div>
</body>
</html>