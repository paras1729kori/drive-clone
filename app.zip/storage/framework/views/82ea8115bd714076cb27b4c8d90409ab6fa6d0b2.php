

<?php $__env->startSection('content'); ?>
<div class="container">
    <ul class="nav navbar-nav navbar-right">
        <!-- Authentication Links -->
        <?php if(Auth::guest()): ?>
        <div class="row text-center mt-5">
            <div class="col-sm-6">
                <li><a href="<?php echo e(route('login')); ?>" class="btn btn-lg font-weight-bolder">Login</a></li>
            </div>
        </div>
        <?php else: ?>
            <li class="dropdown mb-3">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                    <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                </a>

                <ul class="dropdown-menu text-center" role="menu">
                    <li>
                        <a href="<?php echo e(route('logout')); ?>"
                            onclick="event.preventDefault();
                                      document.getElementById('logout-form').submit();">
                            Logout
                        </a>

                        <form id="logout-form" action="/session/logout" method="POST" style="display: none;">
                            <?php echo e(csrf_field()); ?>

                        </form>
                    </li>
                    <hr>
                    <li>
                    <a class="btn btn-link" href="/changepassword/user">Reset Password</a>
                    </li>
                </ul>
            </li>
        <?php endif; ?>
    </ul>
    <h4 class="font-weight-bold">Sent Messages</h4>
    <?php if(count($posts) > 0): ?>
      <div class="row p-2">
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($post->general == '0'): ?>
            <div class="col-sm-2 px-1 py-1">
                <?php
                if($post->reciever == auth()->user()->id){
                  $color = '#82262a';
                }
                elseif($post->user_id == auth()->user()->id){
                  $color = '#212529';
                }
            ?>
            <div class="card text-light" style="background-color:<?php echo e($color); ?>">
                <div class="card-body">
                    <h4><?php echo e($post->title); ?></h4>
                    <h6>From: <?php echo e($post->user->name); ?></h6>
                    <h6>To: <?php echo e($user_names[$post->reciever]); ?></h6>
                    <small>Written on <?php echo e($post->created_at); ?></small>
                <p class="card-text font-italic">
                    <?php echo e($post->body); ?>

                </p>
                <?php if(!Auth::guest()): ?>
                    <?php if(Auth::user()->id == $post->user_id): ?>
                        <a href="/posts/<?php echo e($post->id); ?>/edit" class="btn btn-success btn-default">Edit</a>

                        <?php echo Form::open(['action' => ['PostsController@destroy', $post->id], 'method' => 'DELETE', 'class' => 'pull-right']); ?>

                            <?php echo e(Form::submit('Delete', ['class' => 'btn btn-danger'])); ?>

                        <?php echo Form::close(); ?>

                    <?php endif; ?>
                <?php endif; ?>
                </div>
            </div>
            </div> 
        <?php else: ?>
        <div class="col-sm-2 px-1 py-1">
            <div class="card text-light" style="background-color: rgb(71, 32, 71)">
                <div class="card-body">
                    <h4><?php echo e($post->title); ?></h4>
                    <h6><?php echo e($post->user->name); ?></h6>
                    <small>Written on <?php echo e($post->created_at); ?></small>
                <p class="card-text font-italic">
                    <?php echo e($post->body); ?>

                </p>
                <?php if(!Auth::guest()): ?>
                    <?php if(Auth::user()->id == $post->user_id): ?>
                        <a href="/posts/<?php echo e($post->id); ?>/edit" class="btn btn-success btn-default">Edit</a>

                        <?php echo Form::open(['action' => ['PostsController@destroy', $post->id], 'method' => 'DELETE', 'class' => 'pull-right']); ?>

                            <?php echo e(Form::submit('Delete', ['class' => 'btn btn-danger'])); ?>

                        <?php echo Form::close(); ?>

                    <?php endif; ?>
                <?php endif; ?>
                </div>
            </div>
            </div> 
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    <?php else: ?>
        <p>No messages found</p>
    <?php endif; ?>
    <a href="/posts/create" class="btn btn-primary mb-2">Messages</a>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\jaics\Desktop\Internship\Converse\resources\views/pages/account.blade.php ENDPATH**/ ?>