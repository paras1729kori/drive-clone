

<?php $__env->startSection('title'); ?>
    Edit-Registered Users
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h3>Edit Role and Status for Registered User</h3>
                    </div>
                    <div class="card-body">
                        <div class="col-md-6">
                            <form action="/registerupdate/<?php echo e($users->id); ?>" method="POST">
                                <?php echo e(csrf_field()); ?>

                                <?php echo e(method_field('PUT')); ?>

                                <form>
                                    <div class="form-group">
                                      <label>Name</label>
                                        <input type="text" class="form-control"  value="<?php echo e($users->name); ?>" name="username">
                                    </div>
                                    <div class="form-group">
                                        <label>Give Role</label>
                                        <select name="usertype" class="form-control">
                                            <option value="admin">Admin</option>
                                            <option value="user">User</option>
                                            <option value="">None</option>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label>Give Status</label>
                                        <select name="status" class="form-control">
                                            <option value="active">active</option>
                                            <option value="disabled">disabled</option>
                                        </select>
                                    </div>
                                    <button type="submit" class="btn btn-success">Update</button>
                                    <a href="/registerrole" type="submit" class="btn btn-danger">Cancel</a>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\jaics\Desktop\Internship\Converse\resources\views/admin/register-edit.blade.php ENDPATH**/ ?>