

<?php $__env->startSection('title'); ?>
    Registered Users Data
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
<div class="row">
    <div class="col-md-12">
      <div class="card">
        <div class="card-header">
          <h4 class="card-title"> Registered Users</h4>
          <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
        </div>
        <div class="card-body">
          <div class="table-responsive" id="table_pc">
            <table class="table">
              <thead class="text-primary">
                <th>Id</th>
                <th>Name</th>
                <th>Email</th>
                <th>UserType</th>
                <th>Status</th>
                <th>Login_Time</th>
                <th>Logout_Time</th>
              </thead>
              <tbody>
                  <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><?php echo e($user->id); ?></td>
                        <td><?php echo e($user->name); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td><?php echo e($user->usertype); ?></td>
                        <td><?php echo e($user->status); ?></td>
                        <td>
                          <?php if($user->login_time == null): ?>
                            <p>--------</p>
                          <?php else: ?>
                            <?php echo e($user->login_time); ?>

                          <?php endif; ?>
                        </td>
                        <td>
                          <?php if($user->logout_time == null): ?>
                            <p>--------</p>
                          <?php else: ?>
                            <?php echo e($user->logout_time); ?>

                          <?php endif; ?>
                        </td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  
              </tbody>
            </table>
          </div>
          <div class="table-responsive" id="table_mobile">
            <table class="table">
            <thead class="text-primary">
              <th>Name</th>
              <th>UserType</th>
              <th>Status</th>
            </thead>
            <tbody>
              <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($user->name); ?></td> 
                    <td><?php echo e($user->usertype); ?></td>
                    <td><?php echo e($user->status); ?></td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
           </tbody>
            </table>
            <p>Switch to Destop View to access all the details of a user</p>
          </div>
        </div>
      </div>
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\jaics\Desktop\Internship\Converse\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>