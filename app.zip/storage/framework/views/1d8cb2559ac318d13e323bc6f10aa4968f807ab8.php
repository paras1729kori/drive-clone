

<?php $__env->startSection('content'); ?>
    <div class="container">
    <div id="accordion" role="tablist">
        <div class="card">
          <div class="card-header" role="tab" id="headingOne">
            <h5 class="mb-0">
              <a data-toggle="collapse" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                Upload Files
              </a>
            </h5>
          </div>
      
          <div id="collapseOne" class="collapse show" role="tabpanel" aria-labelledby="headingOne">
            <div class="card-body">
              <?php echo Form::open(['action' => 'FilesController@store', 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

              <div class="form-group">
                <input type="file" name="file[]" multiple>
              </div>
              <div class="form-group">
                <?php echo e(Form::label('parentid', 'Parent Folder')); ?>

                <select class="form-control opt" name="parentid" id="parentid">
                    <option value="<?php echo e($parent); ?>"><?php echo e($fol->name); ?></option>
                </select>
              </div>
                <?php echo e(Form::submit('Upload', ['class'=>'btn btn-primary'])); ?>

                <?php echo Form::close(); ?>

            </div>
          </div>
        </div>
    </div>  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\jaics\Desktop\Internship\Converse\resources\views/files/replace.blade.php ENDPATH**/ ?>