

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="card mt-4">
            <div class="card-header" role="tab" id="headingTwo">
              <h5 class="mb-0">
                <a class="collapsed" data-toggle="collapse" href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                  Edit Folder
                </a>
              </h5>
            </div>
              <div id="collapseTwo" class="collapse show" role="tabpanel" aria-labelledby="headingTwo">
                <div class="card-body">
                <?php echo Form::open(['action' => ['FoldersController@update', $fols->id], 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

                  <div class="form-group">
                  <?php echo e(Form::label('name', 'Name')); ?>

                  <?php echo e(Form::text('name', $fols->name, ['class' => 'form-control', 'placeholder' => 'folder name'])); ?>

                </div>
                <?php echo e(Form::submit('Submit', ['class'=>'btn btn-primary'])); ?>

                <?php echo Form::close(); ?>

              </div>
            </div>
          </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\jaics\Desktop\Internship\Converse\resources\views/folders/edit.blade.php ENDPATH**/ ?>