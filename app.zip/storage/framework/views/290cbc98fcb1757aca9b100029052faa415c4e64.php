

<?php $__env->startSection('content'); ?>
<div class="container">
    <ul class="nav navbar-nav navbar-right">
        <!-- Authentication Links -->
        <?php if(Auth::guest()): ?>
        <div class="row text-center mt-5">
            <div class="col-sm-6">
                <li><a href="<?php echo e(route('login')); ?>" class="btn btn-lg font-weight-bolder">Login</a></li>
            </div>
        </div>
        <?php else: ?>
            <?php echo Form::open(['action' => 'UsersController@SaveNewPass', 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

                <div class="form-group row">
                    <label for="password" style="color:black;"><?php echo e(__('New Password')); ?></label>
                    <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="new-password">
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                
                <div class="form-group row">
                    <label for="password-confirm" style="color:black;"><?php echo e(__('Confirm New Password')); ?></label>
                    <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required autocomplete="new-password">
                </div>
                <?php echo e(Form::submit('Update Password', ['class'=>'btn btn-primary'])); ?>

            <?php echo Form::close(); ?>

        <?php endif; ?>
    </ul>
    
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\jaics\Desktop\Internship\Converse\resources\views/users/changepass.blade.php ENDPATH**/ ?>