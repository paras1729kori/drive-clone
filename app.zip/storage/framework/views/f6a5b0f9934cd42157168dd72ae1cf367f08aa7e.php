

<?php $__env->startSection('content'); ?>
<div class="px-2">
  <div class="row" id="table_pc">
    <div class="col-10">
      
    <h4 class="font-weight-bold">General Messages</h4>
    <?php if(count($posts) > 0): ?>
      <div class="row px-2">
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-sm-2 px-2">
            <div class="card text-light" style="background-color: rgb(71, 32, 71)">
              <div class="card-body">
                <h4><?php echo e($post->title); ?></h4>
                <h6>Written on <?php echo e($post->created_at); ?> by <?php echo e($post->user->name); ?></h6>
                <p class="card-text font-italic">
                  <?php echo e($post->body); ?>

                </p>
                <?php if(!Auth::guest()): ?>
                  <?php if(Auth::user()->id == $post->user_id): ?>
                      <a href="/posts/<?php echo e($post->id); ?>/edit" class="btn btn-success btn-default">Edit</a>

                      <?php echo Form::open(['action' => ['PostsController@destroy', $post->id], 'method' => 'DELETE', 'class' => 'pull-right']); ?>

                          <?php echo e(Form::submit('Delete', ['class' => 'btn btn-danger'])); ?>

                      <?php echo Form::close(); ?>

                  <?php endif; ?>
                <?php endif; ?>
              </div>
            </div>
          </div> 
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
      <?php endif; ?>
      <br>
      
      <h4 class="font-weight-bold">Private Messages</h4>
      <?php if(count($per_posts) > 0): ?>
      <div class="row px-2">
        <?php $__currentLoopData = $per_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-sm-2 px-2">
            <?php
                if($post->reciever == auth()->user()->id){
                  $color = '#82262a';
                }
                elseif($post->user_id == auth()->user()->id){
                  $color = '#212529';
                }
            ?>
            <div class="card text-light" style="background-color:<?php echo e($color); ?>">
              <div class="card-body">
                <h4><?php echo e($post->title); ?></h4>
                <h6>From: <?php echo e($post->user->name); ?></h6>
                <h6>To: <?php echo e($user_names[$post->reciever]); ?></h6>
                <small>Written on <?php echo e($post->created_at); ?></small>
                <p class="card-text font-italic">
                  <?php echo e($post->body); ?>

                </p>
                <?php if(!Auth::guest()): ?>
                  <?php if(Auth::user()->id == $post->user_id): ?>
                      <a href="/posts/<?php echo e($post->id); ?>/edit" class="btn btn-success btn-default">Edit</a>

                      <?php echo Form::open(['action' => ['PostsController@destroy', $post->id], 'method' => 'DELETE', 'class' => 'pull-right']); ?>

                          <?php echo e(Form::submit('Delete', ['class' => 'btn btn-danger'])); ?>

                      <?php echo Form::close(); ?>

                  <?php endif; ?>
                <?php endif; ?>
              </div>
            </div>
          </div> 
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    <?php else: ?>
        <p class="pt-1">No messages found</p>
    <?php endif; ?>
    </div>
    <?php if(Auth::guest() || auth()->user()->usertype == 'admin'): ?>
    <div class="col-2">
      <?php echo Form::open(['action' => 'PostsController@filter', 'method' => 'GET']); ?>

        <div class="form-group">
          <?php echo e(Form::label('filter_by_id', 'Filter by Name')); ?>

          <select class="form-control opt" name="filter_name" id="filter_name">
              <option value="nullable">Select User</option>
              <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <button class="btn btn-primary">Submit</button>
      <?php echo Form::close(); ?>

    </div>
    <?php endif; ?>
  </div>




  <div class="row" id="table_mobile">
    <div class="col-12">
      
    <h4 class="font-weight-bold">General Messages</h4>
    <?php if(count($posts) > 0): ?>
      <div class="row px-2">
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-sm-3 px-2 py-1">
            <div class="card text-light" style="background-color: rgb(71, 32, 71)">
              <div class="card-body">
                <h4><?php echo e($post->title); ?></h4>
                <h6>Written on <?php echo e($post->created_at); ?> by <?php echo e($post->user->name); ?></h6>
                <p class="card-text font-italic">
                  <?php echo e($post->body); ?>

                </p>
                <?php if(!Auth::guest()): ?>
                  <?php if(Auth::user()->id == $post->user_id): ?>
                      <a href="/posts/<?php echo e($post->id); ?>/edit" class="btn btn-success btn-default">Edit</a>

                      <?php echo Form::open(['action' => ['PostsController@destroy', $post->id], 'method' => 'DELETE', 'class' => 'pull-right']); ?>

                          <?php echo e(Form::submit('Delete', ['class' => 'btn btn-danger'])); ?>

                      <?php echo Form::close(); ?>

                  <?php endif; ?>
                <?php endif; ?>
              </div>
            </div>
          </div> 
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
      <?php endif; ?>
      <br>
      
      <h4 class="font-weight-bold">Private Messages</h4>
      <?php if(count($per_posts) > 0): ?>
      <div class="row px-2">
        <?php $__currentLoopData = $per_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-sm-3 px-2 py-1">
            <?php
                if($post->reciever == auth()->user()->id){
                  $color = '#82262a';
                }
                elseif($post->user_id == auth()->user()->id){
                  $color = '#212529';
                }
            ?>
            <div class="card text-light" style="background-color:<?php echo e($color); ?>">
              <div class="card-body">
                <h4><?php echo e($post->title); ?></h4>
                <h6>From: <?php echo e($post->user->name); ?></h6>
                <h6>To: <?php echo e($user_names[$post->reciever]); ?></h6>
                <small>Written on <?php echo e($post->created_at); ?></small>
                <p class="card-text font-italic">
                  <?php echo e($post->body); ?>

                </p>
                <?php if(!Auth::guest()): ?>
                  <?php if(Auth::user()->id == $post->user_id): ?>
                      <a href="/posts/<?php echo e($post->id); ?>/edit" class="btn btn-success btn-default">Edit</a>

                      <?php echo Form::open(['action' => ['PostsController@destroy', $post->id], 'method' => 'DELETE', 'class' => 'pull-right']); ?>

                          <?php echo e(Form::submit('Delete', ['class' => 'btn btn-danger'])); ?>

                      <?php echo Form::close(); ?>

                  <?php endif; ?>
                <?php endif; ?>
              </div>
            </div>
          </div> 
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    <?php else: ?>
        <p class="pt-1">No messages found</p>
    <?php endif; ?>
    </div>
    
  </div>
  <a href="/posts/create" class="btn btn-primary mt-3">Messages</a>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\jaics\Desktop\Internship\Converse\resources\views/posts/index.blade.php ENDPATH**/ ?>