

<?php $__env->startSection('content'); ?>

<div class='container' style="background-color: #fff; border-radius: 20px; padding: 16px;">

    <div id="header">
        <span>Password Reset</span>
    </div>    

    <?php echo Form::open(['action' => 'AuthController@ChangePass', 'method' => 'POST']); ?>

        <div class=form-group>
            <?php echo e(Form::label('password', 'New Password*')); ?>

            <?php echo e(Form::password('password', ['class' => 'form-control', 'placeholder' => 'Password'])); ?>

        </div>

        <div class=form-group>
            <?php echo e(Form::label('password_confirmation', 'Confirm New Password*')); ?>

            <?php echo e(Form::password('password_confirmation', ['class' => 'form-control', 'placeholder' => 'Confirm Password'])); ?>

        </div>

        <?php echo e(Form::hidden('user', $user->id)); ?>

        <?php echo e(Form::submit('Submit', ['class' => 'btn btn-primary'])); ?>

    <?php echo Form::close(); ?>

    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\jaics\Desktop\Internship\Converse\resources\views/users/passReset.blade.php ENDPATH**/ ?>